# CEN4020
Software Engineering Group Project

# How To Compile/Run:   

- ant run -- starts build, compiles if necessary

- ant build -- compiles build

- ant test-run -- starts tests, compiles if necessary

- ant test-build -- compiles tests, compiles build if necessary

- ant clean -- cleans up current build

# Acceptance tests:
- any acceptance testing can be done by creating a user and giving input
                  and checking for error output
